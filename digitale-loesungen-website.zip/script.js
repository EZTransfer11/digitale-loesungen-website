// Smooth scrolling for navigation links
document.addEventListener('DOMContentLoaded', function() {
    // Smooth scrolling for anchor links
    const navLinks = document.querySelectorAll('a[href^="#"]');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetSection.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            hamburger.classList.toggle('active');
        });
    }

    // Header scroll effect with auto-hide/show
    const header = document.querySelector('.header');
    let lastScrollY = window.scrollY;
    let ticking = false;
    
    function updateHeader() {
        const currentScrollY = window.scrollY;
        
        // Add scrolled class for styling
        if (currentScrollY > 100) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
        
        // Auto-hide/show functionality
        if (currentScrollY > lastScrollY && currentScrollY > 200) {
            // Scrolling down - hide header
            header.style.transform = 'translateY(-100%)';
        } else {
            // Scrolling up - show header
            header.style.transform = 'translateY(0)';
        }
        
        lastScrollY = currentScrollY;
        ticking = false;
    }
    
    function requestTick() {
        if (!ticking) {
            requestAnimationFrame(updateHeader);
            ticking = true;
        }
    }
    
    window.addEventListener('scroll', requestTick, { passive: true });

    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const animateElements = document.querySelectorAll('.service-card, .testimonial-card, .pricing-card, .stat-item');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });

    // Counter animation for stats
    const statNumbers = document.querySelectorAll('.stat-number');
    const statsObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                statsObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    statNumbers.forEach(stat => {
        statsObserver.observe(stat);
    });

    function animateCounter(element) {
        const target = parseInt(element.textContent.replace(/[^\d]/g, ''));
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const timer = setInterval(() => {
            current += step;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            
            const suffix = element.textContent.replace(/[\d]/g, '');
            element.textContent = Math.floor(current) + suffix;
        }, 16);
    }
});

// FAQ Accordion functionality
function toggleFAQ(element) {
    const faqItem = element.parentElement;
    const isActive = faqItem.classList.contains('active');
    
    // Close all FAQ items
    document.querySelectorAll('.faq-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Open clicked item if it wasn't active
    if (!isActive) {
        faqItem.classList.add('active');
    }
}

// FAQ Filtering Functionality
function filterFAQ(category) {
    const faqItems = document.querySelectorAll('.faq-item');
    const categoryBtns = document.querySelectorAll('.faq-category-btn');
    
    // Update active button
    categoryBtns.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Filter FAQ items
    faqItems.forEach(item => {
        const itemCategory = item.getAttribute('data-category');
        
        if (category === 'all' || itemCategory === category) {
            item.classList.remove('hidden');
            setTimeout(() => {
                item.style.display = 'block';
            }, 100);
        } else {
            item.classList.add('hidden');
            setTimeout(() => {
                item.style.display = 'none';
            }, 300);
        }
    });
    
    // Track filter usage
    trackConversion('faq_filter_used', { category: category });
}

// Project Filtering Functionality
function filterProjects(category) {
    const projectCards = document.querySelectorAll('.project-card');
    const categoryBtns = document.querySelectorAll('.category-btn');
    
    // Update active button
    categoryBtns.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Filter projects
    projectCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        
        if (category === 'all' || cardCategory === category) {
            card.classList.remove('hidden');
            setTimeout(() => {
                card.style.display = 'block';
            }, 100);
        } else {
            card.classList.add('hidden');
            setTimeout(() => {
                card.style.display = 'none';
            }, 300);
        }
    });
    
    // Track filter usage
    trackConversion('project_filter_used', { category: category });
}

// Enhanced project carousel (keeping for backward compatibility)
let currentProject = 0;
const projects = [
    {
        title: "Mobile App UI Design",
        description: "Moderne mobile Anwendung mit intuitiver Benutzeroberfläche und nahtloser Benutzererfahrung.",
        image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2074&q=80"
    },
    {
        title: "E-Commerce Website",
        description: "Komplette E-Commerce-Lösung mit Zahlungsintegration und Bestandsverwaltung.",
        image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
    },
    {
        title: "Corporate Website",
        description: "Professionelle Unternehmenswebsite mit modernem Design und responsivem Layout.",
        image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2015&q=80"
    },
    {
        title: "SaaS Dashboard",
        description: "Umfassendes Dashboard für SaaS-Anwendungen mit Analytics und Berichterstattung.",
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
    }
];

function changeProject(direction) {
    currentProject += direction;
    
    if (currentProject >= projects.length) {
        currentProject = 0;
    } else if (currentProject < 0) {
        currentProject = projects.length - 1;
    }
    
    updateProjectDisplay();
}

function updateProjectDisplay() {
    const projectCard = document.querySelector('.project-card');
    const project = projects[currentProject];
    
    if (projectCard) {
        projectCard.innerHTML = `
            <div class="project-image">
                <img src="${project.image}" alt="${project.title}">
            </div>
            <div class="project-content">
                <h3>${project.title}</h3>
                <p>${project.description}</p>
            </div>
        `;
    }
}

// Auto-rotate projects every 5 seconds
setInterval(() => {
    changeProject(1);
}, 5000);

// Form handling (if forms are added later)
function handleFormSubmit(form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);
        
        // Show success message
        showNotification('Vielen Dank für Ihre Nachricht! Wir werden uns bald bei Ihnen melden.', 'success');
        
        // Reset form
        form.reset();
    });
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#6366f1'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        z-index: 10000;
        max-width: 400px;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Add CSS for notification animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .notification-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
    }
    
    .notification-content button {
        background: none;
        border: none;
        color: white;
        font-size: 1.5rem;
        cursor: pointer;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .notification-content button:hover {
        opacity: 0.8;
    }
`;
document.head.appendChild(style);

// Lazy loading for images
function lazyLoadImages() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}

// Initialize lazy loading
document.addEventListener('DOMContentLoaded', lazyLoadImages);

// Performance optimization: Debounce scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Optimized scroll handler
const optimizedScrollHandler = debounce(() => {
    // Scroll-based animations and effects
    const scrolled = window.pageYOffset;
    const parallax = document.querySelectorAll('.parallax');
    
    parallax.forEach(element => {
        const speed = element.dataset.speed || 0.5;
        element.style.transform = `translateY(${scrolled * speed}px)`;
    });
}, 10);

window.addEventListener('scroll', optimizedScrollHandler);

// Booking Modal Functions
function openBookingModal() {
    const modal = document.getElementById('bookingModal');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Track conversion event
    trackConversion('booking_modal_opened');
}

function closeBookingModal() {
    const modal = document.getElementById('bookingModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
}

function submitBooking() {
    const form = document.querySelector('.booking-form');
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);
    
    // Validate required fields
    if (!data.name || !data.email) {
        showNotification('Bitte füllen Sie alle Pflichtfelder aus.', 'error');
        return;
    }
    
    // Simulate booking submission
    showNotification('Termin erfolgreich gebucht! Wir melden uns innerhalb von 24h bei Ihnen.', 'success');
    closeBookingModal();
    
    // Track successful booking
    trackConversion('booking_completed');
    
    // Reset form
    form.reset();
}

// Exit Intent Popup Functions
function closeExitIntent() {
    const popup = document.getElementById('exitIntentPopup');
    popup.classList.remove('active');
    document.body.style.overflow = 'auto';
}

// Scroll to section function
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        const headerHeight = document.querySelector('.header').offsetHeight;
        const targetPosition = section.offsetTop - headerHeight - 20;
        
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
    }
}

// Conversion tracking
function trackConversion(event) {
    console.log('Conversion Event:', event);
    // Here you would integrate with Google Analytics, Facebook Pixel, etc.
    // Example: gtag('event', event, { 'event_category': 'conversion' });
}

// Exit Intent Detection
let exitIntentShown = false;
document.addEventListener('mouseout', function(e) {
    if (e.clientY <= 0 && !exitIntentShown) {
        exitIntentShown = true;
        setTimeout(() => {
            const popup = document.getElementById('exitIntentPopup');
            popup.classList.add('active');
            document.body.style.overflow = 'hidden';
            trackConversion('exit_intent_popup_shown');
        }, 1000);
    }
});

// Floating CTA Button
function createFloatingCTA() {
    const floatingCTA = document.createElement('button');
    floatingCTA.className = 'floating-cta';
    floatingCTA.innerHTML = '<i class="fas fa-calendar-check"></i> Termin buchen';
    floatingCTA.onclick = openBookingModal;
    
    document.body.appendChild(floatingCTA);
    
    // Show after 3 seconds
    setTimeout(() => {
        floatingCTA.style.display = 'flex';
    }, 3000);
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Digitale Lösungen Website erfolgreich geladen!');
    
    // Create and show loading screen
    createLoadingScreen();
    
    // Create floating CTA
    createFloatingCTA();
});

// Modern Loading Screen
function createLoadingScreen() {
    const loader = document.createElement('div');
    loader.id = 'page-loader';
    loader.innerHTML = `
        <div class="loader-container">
            <div class="loader-spinner">
                <div class="spinner-ring"></div>
                <div class="spinner-ring"></div>
                <div class="spinner-ring"></div>
                <div class="spinner-ring"></div>
            </div>
            <div class="loader-text">
                <span class="loader-title">DigitaleLösungen</span>
                <span class="loader-subtitle">Laden...</span>
            </div>
        </div>
    `;
    
    loader.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        transition: opacity 0.5s ease;
    `;
    
    document.body.appendChild(loader);
    
    // Add loader CSS
    const loaderStyle = document.createElement('style');
    loaderStyle.textContent = `
        .loader-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 2rem;
        }
        
        .loader-spinner {
            position: relative;
            width: 80px;
            height: 80px;
        }
        
        .spinner-ring {
            position: absolute;
            width: 100%;
            height: 100%;
            border: 3px solid transparent;
            border-radius: 50%;
            animation: spin 1.5s linear infinite;
        }
        
        .spinner-ring:nth-child(1) {
            border-top-color: #6366f1;
            animation-delay: 0s;
        }
        
        .spinner-ring:nth-child(2) {
            border-right-color: #8b5cf6;
            animation-delay: 0.1s;
        }
        
        .spinner-ring:nth-child(3) {
            border-bottom-color: #06b6d4;
            animation-delay: 0.2s;
        }
        
        .spinner-ring:nth-child(4) {
            border-left-color: #10b981;
            animation-delay: 0.3s;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .loader-text {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
        }
        
        .loader-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1f2937;
            letter-spacing: 0.05em;
        }
        
        .loader-subtitle {
            font-size: 0.875rem;
            color: #6b7280;
            font-weight: 500;
        }
    `;
    document.head.appendChild(loaderStyle);
    
    // Remove loader after page is fully loaded
    window.addEventListener('load', () => {
        setTimeout(() => {
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.remove();
                loaderStyle.remove();
            }, 500);
        }, 1500); // Show loader for 1.5 seconds minimum
    });
}

// Client Logos Animation - Continuous running (no pause functionality)

// Calendar Booking System
let currentDate = new Date();
let selectedDate = null;
let selectedTime = null;

const monthNames = [
    "Januar", "Februar", "März", "April", "Mai", "Juni",
    "Juli", "August", "September", "Oktober", "November", "Dezember"
];

const dayNames = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];

const timeSlots = [
    "09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00"
];

function generateCalendar() {
    const calendarGrid = document.getElementById('calendarGrid');
    const currentMonthElement = document.getElementById('currentMonth');
    
    if (!calendarGrid || !currentMonthElement) return;
    
    // Update month display
    currentMonthElement.textContent = `${monthNames[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
    
    // Clear calendar
    calendarGrid.innerHTML = '';
    
    // Add day headers
    dayNames.forEach(day => {
        const dayHeader = document.createElement('div');
        dayHeader.className = 'calendar-day-header';
        dayHeader.textContent = day;
        calendarGrid.appendChild(dayHeader);
    });
    
    // Get first day of month and number of days
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
        const emptyDay = document.createElement('div');
        emptyDay.className = 'calendar-day disabled';
        calendarGrid.appendChild(emptyDay);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day';
        dayElement.textContent = day;
        
        const dayDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
        const today = new Date();
        
        // Check if it's today
        if (dayDate.toDateString() === today.toDateString()) {
            dayElement.classList.add('today');
        }
        
        // Check if it's in the past
        if (dayDate < today.setHours(0, 0, 0, 0)) {
            dayElement.classList.add('disabled');
        } else {
            // Add click event for selectable days
            dayElement.addEventListener('click', () => selectDate(dayDate));
        }
        
        // Check if it's selected
        if (selectedDate && dayDate.toDateString() === selectedDate.toDateString()) {
            dayElement.classList.add('selected');
        }
        
        calendarGrid.appendChild(dayElement);
    }
}

function selectDate(date) {
    selectedDate = date;
    selectedTime = null;
    
    // Update UI
    const selectedDateText = document.getElementById('selectedDateText');
    const timeSelection = document.getElementById('timeSelection');
    const bookingForm = document.getElementById('bookingForm');
    
    if (selectedDateText) {
        selectedDateText.textContent = `${date.getDate()}. ${monthNames[date.getMonth()]} ${date.getFullYear()}`;
    }
    
    // Show time selection
    if (timeSelection) {
        timeSelection.style.display = 'block';
        generateTimeSlots();
    }
    
    // Hide booking form until time is selected
    if (bookingForm) {
        bookingForm.style.display = 'none';
    }
    
    // Regenerate calendar to update selected state
    generateCalendar();
}

function generateTimeSlots() {
    const timeSlotsContainer = document.getElementById('timeSlots');
    if (!timeSlotsContainer) return;
    
    timeSlotsContainer.innerHTML = '';
    
    timeSlots.forEach(time => {
        const timeSlot = document.createElement('div');
        timeSlot.className = 'time-slot';
        timeSlot.textContent = time;
        
        // Randomly disable some slots to simulate availability
        if (Math.random() < 0.3) {
            timeSlot.classList.add('disabled');
        } else {
            timeSlot.addEventListener('click', () => selectTime(time));
        }
        
        timeSlotsContainer.appendChild(timeSlot);
    });
}

function selectTime(time) {
    selectedTime = time;
    
    // Update UI
    const timeSlots = document.querySelectorAll('.time-slot');
    timeSlots.forEach(slot => {
        slot.classList.remove('selected');
        if (slot.textContent === time) {
            slot.classList.add('selected');
        }
    });
    
    // Show booking form
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.style.display = 'block';
    }
}

function changeMonth(direction) {
    currentDate.setMonth(currentDate.getMonth() + direction);
    generateCalendar();
}

// Initialize calendar when modal opens
function openBookingModal() {
    const modal = document.getElementById('bookingModal');
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Auto-select today's date
        const today = new Date();
        selectedDate = today;
        selectedTime = null;
        
        // Generate calendar
        generateCalendar();
        
        // Auto-show time selection for today
        const timeSelection = document.getElementById('timeSelection');
        const bookingForm = document.getElementById('bookingForm');
        const selectedDateText = document.getElementById('selectedDateText');
        
        if (selectedDateText) {
            selectedDateText.textContent = `${today.getDate()}. ${monthNames[today.getMonth()]} ${today.getFullYear()}`;
        }
        
        if (timeSelection) {
            timeSelection.style.display = 'block';
            generateTimeSlots();
        }
        
        // Hide booking form initially
        if (bookingForm) {
            bookingForm.style.display = 'none';
        }
    }
}

function closeBookingModal() {
    const modal = document.getElementById('bookingModal');
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
}

// Scroll to Top Button
const scrollToTopBtn = document.getElementById('scrollToTop');

window.addEventListener('scroll', function() {
    if (window.pageYOffset > 300) {
        scrollToTopBtn.classList.add('visible');
    } else {
        scrollToTopBtn.classList.remove('visible');
    }
});

scrollToTopBtn.addEventListener('click', function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Cookie Consent Management
let cookieConsent = localStorage.getItem('cookieConsent');

if (!cookieConsent) {
    setTimeout(() => {
        document.getElementById('cookieConsent').classList.add('show');
    }, 2000);
}

function acceptCookies() {
    localStorage.setItem('cookieConsent', 'accepted');
    document.getElementById('cookieConsent').classList.remove('show');
    // Enable analytics and marketing cookies
    console.log('Cookies accepted - Analytics and marketing enabled');
}

function declineCookies() {
    localStorage.setItem('cookieConsent', 'declined');
    document.getElementById('cookieConsent').classList.remove('show');
    // Only enable necessary cookies
    console.log('Cookies declined - Only necessary cookies enabled');
}

function showCookieSettings() {
    document.getElementById('cookieSettingsModal').classList.add('active');
}

function closeCookieSettings() {
    document.getElementById('cookieSettingsModal').classList.remove('active');
}

function saveCookieSettings() {
    const analyticsCookies = document.getElementById('analyticsCookies').checked;
    const marketingCookies = document.getElementById('marketingCookies').checked;
    
    localStorage.setItem('cookieConsent', 'custom');
    localStorage.setItem('analyticsCookies', analyticsCookies);
    localStorage.setItem('marketingCookies', marketingCookies);
    
    document.getElementById('cookieSettingsModal').classList.remove('active');
    document.getElementById('cookieConsent').classList.remove('show');
    
    console.log('Cookie settings saved:', { analyticsCookies, marketingCookies });
}


// Interactive Timeline Animation
function animateTimeline() {
    const timelineItems = document.querySelectorAll('.timeline-item');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
            }
        });
    }, { threshold: 0.3 });
    
    timelineItems.forEach((item) => {
        observer.observe(item);
    });
}

// Interactive Project Showcase
function initProjectShowcase() {
    const colorBtns = document.querySelectorAll('.color-btn');
    const layoutBtns = document.querySelectorAll('.layout-btn');
    const animationsToggle = document.getElementById('animationsToggle');
    const contentBlocks = document.querySelectorAll('.content-block');
    
    // Color picker functionality
    colorBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            colorBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const color = this.dataset.color;
            contentBlocks.forEach((block, index) => {
                if (index === 0) {
                    block.style.background = color;
                    block.style.opacity = '0.8';
                } else if (index === 1) {
                    block.style.background = color;
                    block.style.opacity = '0.6';
                } else if (index === 2) {
                    block.style.background = color;
                    block.style.opacity = '0.4';
                }
            });
        });
    });
    
    // Layout functionality
    layoutBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            layoutBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const layout = this.dataset.layout;
            const screenBody = document.querySelector('.screen-body');
            
            switch(layout) {
                case 'grid':
                    screenBody.style.display = 'grid';
                    screenBody.style.gridTemplateColumns = '1fr 1fr';
                    screenBody.style.gridTemplateRows = '1fr 1fr';
                    break;
                case 'list':
                    screenBody.style.display = 'flex';
                    screenBody.style.flexDirection = 'column';
                    break;
                case 'card':
                    screenBody.style.display = 'flex';
                    screenBody.style.flexDirection = 'row';
                    screenBody.style.gap = '10px';
                    break;
            }
        });
    });
    
    // Animation toggle
    animationsToggle.addEventListener('change', function() {
        contentBlocks.forEach(block => {
            if (this.checked) {
                block.style.animation = 'pulse 2s ease-in-out infinite';
            } else {
                block.style.animation = 'none';
            }
        });
    });
}

// Animated Testimonials Data and Functions
const testimonialsData = [
    {
        text: "Die Zusammenarbeit war fantastisch! Das Team hat unsere Vision perfekt umgesetzt und dabei unsere Erwartungen übertroffen.",
        name: "Sarah Müller",
        role: "Geschäftsführerin, TechStart GmbH",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
        rating: 5
    },
    {
        text: "Professionelle Arbeit und schnelle Umsetzung. Wir sind sehr zufrieden mit dem Ergebnis und der Kommunikation.",
        name: "Michael Weber",
        role: "Marketing Director, Digital Solutions",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
        rating: 5
    },
    {
        text: "Hervorragende Beratung und Umsetzung. Das Team versteht die Bedürfnisse der Kunden und liefert qualitativ hochwertige Lösungen.",
        name: "Anna Schmidt",
        role: "CEO, Innovation Hub",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
        rating: 5
    },
    {
        text: "Sehr empfehlenswert! Die Website ist nicht nur schön geworden, sondern auch funktional und benutzerfreundlich.",
        name: "Thomas Klein",
        role: "Gründer, E-Commerce Plus",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
        rating: 5
    },
    {
        text: "Das Team hat unsere komplexen Anforderungen verstanden und eine Lösung entwickelt, die alle unsere Ziele erreicht.",
        name: "Lisa Hoffmann",
        role: "CTO, DataFlow Systems",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face",
        rating: 5
    },
    {
        text: "Ausgezeichnete Kommunikation und pünktliche Lieferung. Wir würden definitiv wieder mit diesem Team arbeiten.",
        name: "David Wagner",
        role: "Projektmanager, FutureTech",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face",
        rating: 5
    },
    {
        text: "Die App ist genau das geworden, was wir uns vorgestellt haben. Benutzerfreundlich und mit allen gewünschten Features.",
        name: "Julia Fischer",
        role: "Produktmanagerin, AppVenture",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=face",
        rating: 5
    },
    {
        text: "Professionelle Herangehensweise und kreative Lösungen. Das Team hat unsere Ideen zum Leben erweckt.",
        name: "Markus Richter",
        role: "Designer, Creative Studio",
        avatar: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop&crop=face",
        rating: 5
    },
    {
        text: "Schnelle Umsetzung und hohe Qualität. Die Website lädt schnell und funktioniert auf allen Geräten einwandfrei.",
        name: "Nicole Bauer",
        role: "Marketing Managerin, Retail Plus",
        avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop&crop=face",
        rating: 5
    }
];

function createTestimonialCard(testimonial) {
    const card = document.createElement('div');
    card.className = 'testimonial-card';
    
    const stars = '★'.repeat(testimonial.rating);
    
    card.innerHTML = `
        <div class="testimonial-rating">
            <span class="star">${stars}</span>
        </div>
        <div class="testimonial-text">
            "${testimonial.text}"
        </div>
        <div class="testimonial-author">
            <img src="${testimonial.avatar}" alt="${testimonial.name}" class="testimonial-avatar">
            <div class="testimonial-info">
                <div class="testimonial-name">${testimonial.name}</div>
                <div class="testimonial-role">${testimonial.role}</div>
            </div>
        </div>
    `;
    
    return card;
}

function initAnimatedTestimonials() {
    const columns = [
        document.getElementById('testimonialsColumn1'),
        document.getElementById('testimonialsColumn2'),
        document.getElementById('testimonialsColumn3')
    ];
    
    // Distribute testimonials across columns
    testimonialsData.forEach((testimonial, index) => {
        const columnIndex = index % 3;
        const card = createTestimonialCard(testimonial);
        columns[columnIndex].appendChild(card);
    });
    
    // Duplicate testimonials for seamless loop
    testimonialsData.forEach((testimonial, index) => {
        const columnIndex = index % 3;
        const card = createTestimonialCard(testimonial);
        columns[columnIndex].appendChild(card);
    });
}

// Initialize all features when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize carousel
    initCarousel();
    
    // Initialize accordion
    initAccordion();
    
    // Initialize smooth scrolling
    initSmoothScrolling();
    
    // Initialize header scroll effect
    initHeaderScrollEffect();
    
    // Initialize mobile menu
    initMobileMenu();
    
    // Initialize exit intent popup
    initExitIntentPopup();
    
    // Initialize floating CTA
    initFloatingCTA();
    
    // Initialize project filtering
    initProjectFiltering();
    
    // Initialize FAQ filtering
    initFAQFiltering();
    
    // Initialize animated statistics
    initAnimatedStats();
    
    // Initialize calendar booking system
    initCalendarBooking();
    
    // Initialize client logos animation
    initClientLogosAnimation();
    
    // Initialize animated testimonials
    initAnimatedTestimonials();
});
